# WordPress Vitals Plugin
Deze plugin maakt een rest export van de vitale gegevens van WordPress, status updates zoals Core versie en plugins.

Plugin genereert een api key te vinden in het WP CMS.